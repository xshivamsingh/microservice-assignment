package com.impact.customerms.common;


  public enum OrderStatus { placed, returned, cancelled, delivered }
 