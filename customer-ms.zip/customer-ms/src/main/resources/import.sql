insert into customer_tb (contact, email, name, status) values ('+91 3345361', 'abc@gmail.com', 'Akash','ACTIVE');
insert into customer_tb (contact, email, name, status) values ('+91 123445', 'xyz@gmail.com', 'Bhagat','ACTIVE');
insert into customer_tb (contact, email, name, status) values ('+91 8263664', 'mno@gmail.com', 'Sanjay','INACTIVE');
insert into customer_tb (contact, email, name, status) values ('+91 1ttt3', 'qwe@gmail.com', 'Raj','ACTIVE');
insert into CUSTOMER_ORDERS(customer_c_id, orderids) values (1,1);
insert into CUSTOMER_ORDERS(customer_c_id, orderids) values (1,2);
insert into CUSTOMER_ORDERS(customer_c_id, orderids) values (3,4);
insert into CUSTOMER_ORDERS(customer_c_id, orderids) values (3,3);
insert into CUSTOMER_ORDERS(customer_c_id, orderids) values (4,5);
insert into CUSTOMER_ADDRESS ( customer_id,state, city, pincode, street_name) values(1,'Maharashtra', 'Mumbai', 400001, 'LBS marg');
insert into CUSTOMER_ADDRESS ( customer_id,state, city, pincode, street_name) values(1, 'Punjab', 'Amritsar', 400001, 'LBS marg');
insert into CUSTOMER_ADDRESS (customer_id,state, city, pincode, street_name) values(2, 'Maharashtra', 'Mumbai', 400001, 'LBS marg');
     