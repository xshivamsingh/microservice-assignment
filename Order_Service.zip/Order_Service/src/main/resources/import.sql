insert into order_tb (amount, customer_id, product_id, quantity, status) values(99, 1, 1, 1, 'placed');
insert into order_tb (amount, customer_id, product_id, quantity, status) values(101, 1, 2, 1, 'cancelled');
insert into order_tb (amount, customer_id, product_id, quantity, status) values(2000, 1, 2, 1, 'returned');
insert into order_tb (amount, customer_id, product_id, quantity, status) values(999, 4, 1, 3, 'delivered');
