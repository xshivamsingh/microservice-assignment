package com.citiustech.orderms.controller;

import java.util.List;
import java.util.Optional;

import javax.persistence.Id;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.citiustech.orderms.common.OrderRequest;
import com.citiustech.orderms.common.Product;
import com.citiustech.orderms.model.Order;
import com.citiustech.orderms.model.OrderStatus;
import com.citiustech.orderms.repository.OrderRepository;
import com.citiustech.orderms.service.OrderService;

@RestController
@RequestMapping("/orderms")
public class OrderController {
	
	/*
	 * @Autowired private OrderService orderService;
	 */
	
	@Autowired
	private OrderRepository repo;
	
	@Autowired
	RestTemplate restTemplate;
	
	@PostMapping("/order-create")
	public ResponseEntity<Object> addOrder(@RequestBody OrderRequest orderRequest) {
		Order order=new Order();
		
		Long productId = orderRequest.getProductId();
		Object price = restTemplate.getForObject("http://localhost:8083/productms/product-price?productId="+productId, Object.class);
		Integer quantity = orderRequest.getQuantity();
		order.setQuantity(quantity);
		order.setProductId(productId);
		order.setStatus(OrderStatus.placed);
		order.setAmount((Integer)price*quantity);
		order.setCustomerId(orderRequest.getCustomerId());
		repo.save(order);
		return ResponseEntity.ok(order);
		
	}
	
	@GetMapping("/order-by-cid")
	public ResponseEntity<List<Order>> getOrderByCustomerId(@RequestParam Long customerId) {
		
		List<Order> order = repo.findByCustomerId(customerId);
		return ResponseEntity.ok().body(order);
		
	}
	
	@GetMapping("/orders")
	public List<Order> getAllOrders(){
		return repo.findAll();
		
	}
	
	@PatchMapping("/update-order-status")
	public ResponseEntity<String> updateOrder(@RequestParam Long id,@RequestParam OrderStatus status){
		
		Optional<Order> myOrder = repo.findById(id);
		if(myOrder.isPresent()) {
			myOrder.get().setStatus(status);
			repo.save(myOrder.get());
			return ResponseEntity.ok("Order status updated!");
		}
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No order found!");
	}
	
	@GetMapping("/orders/{orderId}")
	public ResponseEntity<Order> getOrderById(@PathVariable("orderId") Long orderId) {
		
		Optional<Order> order = repo.findById(orderId);
		
		if(order.isPresent()) {
			return ResponseEntity.ok(order.get());
		}
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(order.get());
		
	}

}
