package com.citiustech.orderms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.citiustech.orderms.model.Order;

@Service
public class OrderService {

	/*
	 * public Order saveOrder(Order order) {
	 * 
	 * }
	 * 
	 * public List<Order> getOrderByID(Long orderId);
	 */

}
