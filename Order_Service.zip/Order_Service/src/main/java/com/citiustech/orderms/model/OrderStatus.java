package com.citiustech.orderms.model;

public enum OrderStatus {
	
	placed, returned, cancelled, delivered;

}
