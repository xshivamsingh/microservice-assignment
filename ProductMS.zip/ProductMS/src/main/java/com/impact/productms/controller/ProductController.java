package com.impact.productms.controller;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.impact.productms.model.Product;
import com.impact.productms.repo.ProductRepository;

@RestController
public class ProductController {
	
	@Autowired
	private ProductRepository repository;
	//ProductService productService;
	
	@PostMapping("/add-product")
	public ResponseEntity<Product> addProduct(@RequestBody Product product) {
		Product myProduct=repository.save(product);
		return ResponseEntity.status(HttpStatus.CREATED).body(myProduct);
	}
	
	@PutMapping("/update-product")
	public ResponseEntity<String> updateProduct(@RequestBody Product product){
		Optional<Product> myProduct = repository.findById(product.getProductId());
		if(myProduct.isPresent()) {
			repository.save(product);
			return ResponseEntity.status(HttpStatus.OK).body("Product updated");
		}
		return ResponseEntity.ok("Product not found!");
	}
	
	@PatchMapping("/update-product-details")
	public ResponseEntity<String> updateProductDetails(@RequestParam Long id,@RequestBody Map<String, String> details) {
		Optional<Product> myProduct = repository.findById(id);
		if(myProduct.isPresent()) {
			Map<String, String> existingDetails = myProduct.get().getDetails();
			for(Entry<String,String> i:details.entrySet()) {
				existingDetails.put(i.getKey(), i.getValue());
			}
			myProduct.get().setDetails(existingDetails);
			repository.save(myProduct.get());
			return ResponseEntity.status(HttpStatus.OK).body("Product details updated");
		}
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Product not found!!");
	}
	

	/*
	 * @PatchMapping("/update-product-details") public ResponseEntity<String>
	 * updateProductDetails(@RequestParam Long id,@RequestBody Map<String, String>
	 * details) { Optional<Product> myProduct = repository.findById(id);
	 * if(myProduct.isPresent()) { Map<String, String> existingDetails =
	 * myProduct.get().getDetails(); for(Entry<String,String> i:details.entrySet())
	 * { existingDetails.put(i.getKey(), i.getValue()); }
	 * myProduct.get().setDetails(existingDetails);
	 * repository.save(myProduct.get()); return
	 * ResponseEntity.status(HttpStatus.OK).body("Product details updated"); }
	 * 
	 * return
	 * ResponseEntity.status(HttpStatus.NOT_FOUND).body("Product not found!!"); }
	 */
	@PutMapping("/add-product-details")
	public ResponseEntity<String> addProductDetails(@RequestParam Long id,@RequestParam String deatil_name,
			@RequestParam String detail_value) {
		Optional<Product> myProduct = repository.findById(id);
		if(myProduct.isPresent()) {
			myProduct.get().addDetails(deatil_name, detail_value);
			repository.save(myProduct.get());
			return ResponseEntity.status(HttpStatus.OK).body("Product details added");
		}
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Product not found!!");
	}
	
	@GetMapping("/product-by-id/{id}")
	public ResponseEntity<Product> getProductById(@RequestParam Long id) {
		Optional<Product> product = repository.findById(id);
		if(product.isPresent()) return ResponseEntity.status(HttpStatus.FOUND).body(product.get());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	}
	
	@GetMapping("/products/{category}")
	public ResponseEntity<List<Product>> getProductByCategory(@RequestParam String category) {
		return ResponseEntity.status(HttpStatus.OK).body(repository.findByCategory(category));
		
	}
	
	@GetMapping("/products")
	public ResponseEntity<List<Product>> getAllProducts() {
		return ResponseEntity.ok(repository.findAll());
	}
	
	@DeleteMapping("/delete-product/{id}")
	public ResponseEntity<String> deleteProduct(@RequestParam Long id) {
		  Optional<Product> myProduct = repository.findById(id);
		  if(myProduct.isPresent()) { 
			  repository.deleteById(id);
			  return ResponseEntity.ok("product deleted!");}
		  return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Product not found!!");
	}
	
}
